Evidence archive collected by Kestrel at Station 17. Preserve the original files. Compare the manifest to the intercept identifiers before decoding.
